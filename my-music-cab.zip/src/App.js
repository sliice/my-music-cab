import { useCallback, useEffect, useState } from 'react';
import { useHttp } from './hooks/http'
import { client_id, redirect_uri } from './static/data'

export const App = () => {

  const { request } = useHttp();
  const [isDataFetched, setIsDataFetched] = useState(false);
  const fetchData = useCallback( async() => {
    try {

      
      // const url = 'https://api.spotify.com/v1/artists/1vCWHaC5f2uS3yhpwWbIA6/albums?album_type=SINGLE&offset=20&limit=10';
      const url = `https://accounts.spotify.com/authorize?client_id=${ client_id }&response_type=code&redirect_uri=${ redirect_uri }&scope=user-read-email`;
      // const data = await request(url, 'GET', null);
      // if (data) {
      //   setIsDataFetched(true);
      //   console.log(data);
      // }
      //https://accounts.spotify.com/authorize?client_id=18010c5f422e4afa852b6f64aa15e002&response_type=code&redirect_uri=http://localhost:3000&scope=user-read-email
    }
    catch(e){
      console.log(e);
    }
  }, [] );

  useEffect( () => {
    if (!isDataFetched){
      fetchData();
    }
  });
  

  return (
    <div className="App">
      HEY
    </div>
  );
}

export default App;
