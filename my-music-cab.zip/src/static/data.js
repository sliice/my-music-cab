export const client_id = '';
export const redirect_uri = 'http://localhost:3000';